package controllers

import javax.inject._
import models.Compliance
import play.api.mvc._
import play.api.libs.json._

/**
 * This controller creates an `Action` to handle HTTP requests to the
 * application's home page.
 */
@Singleton
class HomeController @Inject()(cc: ControllerComponents) extends AbstractController(cc) {

  /**
   * Create an Action to render an HTML page.
   *
   * The configuration in the `routes` file means that this method
   * will be called when the application receives a `GET` request with
   * a path of `/`.
   */
  def index() = Action { implicit request: Request[AnyContent] =>
    Ok(views.html.index())
  }

  /**
   * This method will be called when the application receives a GET request with following patterns :
   * /compliance , /compliance/:comp_type, /compliance/:comp_type/name
   */
  def getCompliance(compliance_type: String, data: String)  = Action {
    val compliance_val = Compliance(compliance_type, data)
    Ok(Json.toJson(compliance_val))
  }
}
