package models

import play.api.libs.json._

/**
 * This is Compliance class which receives below parameters.
 * @param compliance_type - this is first optional parameter type passed in URL.
 * @param data - this is extra input passed in URL after type parameter.
 * In this class companion object is created. Also write method is defined to generate JSON from Compliance class object.
 */

case class Compliance(compliance_type: String, data: String = "")

object Compliance {

  implicit object complianceFormat extends Writes[Compliance] {

    //Serialization : Compliance -> JSON
    def writes(comp: Compliance): JsValue = {
      var compliance_list: Seq[(String, JsNumber)] = null

      /**
       * Created object of Random class and generated random values between 0 and 1 for type
       * gdpr, unprotected-devices and uninspectable-data.
       * Converted random number generated to two decimal points.
       */
      val random = new scala.util.Random()
      val gdpr_val    = (math floor(random.nextDouble() * 100))/ 100
      val devices_val = (math floor(random.nextDouble() * 100))/ 100
      val data_val    = (math floor(random.nextDouble() * 100))/ 100

      //type is not provided here so generated JSON with all types.
      if(comp.compliance_type.isEmpty) {
        compliance_list = Seq("gdpr" -> JsNumber(gdpr_val), "unprotected-devices" -> JsNumber(devices_val),
          "uninspectable-data" -> JsNumber(data_val))
      }
      else {
        //type is provided so JSON for particular type will get generated.
        compliance_list = comp.compliance_type match {
          case "gdpr" => Seq("gdpr" -> JsNumber(gdpr_val))
          case "unprotected-devices" => Seq("unprotected-devices" -> JsNumber(devices_val))
          case "uninspectable-data" => Seq("uninspectable-data" -> JsNumber(data_val))
          case _ => throw new Exception("Match Error") //Throwing exception because no valid type is provided
        }

        //Throwing exception because other parameters are passed with valid URL
        if(!comp.data.isEmpty)
          throw new Exception("Incorrect IO")
      }
      JsObject(Seq("compliance" -> JsObject(compliance_list)))
    }
  }
}
