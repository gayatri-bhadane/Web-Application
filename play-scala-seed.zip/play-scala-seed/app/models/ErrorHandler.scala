package models

import play.api.http.{HttpErrorHandler}
import play.api.mvc._
import play.api.mvc.Results._

import scala.concurrent._
import javax.inject.Singleton

/**
 * This class is created for Error handling.
 * All client side errors are handled in onClientError function.
 * All server side errors and exception which are thrown like 'Match_error' for incorrect type and 'Incorrect IO' for
 * extra input parameters in URL are handled in onServerError function.
 */

@Singleton
class ErrorHandler extends HttpErrorHandler {
  def onClientError(request: RequestHeader, statusCode: Int, message: String): Future[Result] = {
    statusCode match {
      case 400 => Future.successful(BadRequest(views.html.error_log(s"$statusCode - Bad Request",
                                  "The request could not be understood by the server. " +
                                    "Please enter the correct URL parameter.")))
      case 404 => Future.successful(NotFound(views.html.error_log(s"$statusCode - Page Not Found",
                                  "The requested URL " + request.uri + " is not found on this server.")))
      case _   => Future.successful(BadRequest)
    }
  }

  def onServerError(request: RequestHeader, exception: Throwable): Future[Result] = {
    exception.getMessage match {
      case "Match Error" => Future.successful(NotFound(views.html.error_log("404 - Page Not Found", "The requested URL " +
                                             request.uri + " is not found on this server.")))
      case "Incorrect IO" => Future.successful(BadRequest(views.html.error_log("400 - Bad Request",
                                        "The request could not be understood by the server. " + "Please enter the correct URL parameter.")))
      case _ => Future.successful(InternalServerError("A server error occurred: " + exception.getMessage))
    }
  }
}

